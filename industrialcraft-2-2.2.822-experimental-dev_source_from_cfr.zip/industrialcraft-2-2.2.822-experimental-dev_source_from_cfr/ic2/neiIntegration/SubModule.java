/*
 * Decompiled with CFR 0_115.
 */
package ic2.neiIntegration;

public class SubModule {
    public static boolean init() {
        return true;
    }
}

