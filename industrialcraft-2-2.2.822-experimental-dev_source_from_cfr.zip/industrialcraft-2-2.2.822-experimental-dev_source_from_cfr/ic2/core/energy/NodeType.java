/*
 * Decompiled with CFR 0_115.
 */
package ic2.core.energy;

enum NodeType {
    Source,
    Sink,
    Conductor;
    

    private NodeType() {
    }
}

