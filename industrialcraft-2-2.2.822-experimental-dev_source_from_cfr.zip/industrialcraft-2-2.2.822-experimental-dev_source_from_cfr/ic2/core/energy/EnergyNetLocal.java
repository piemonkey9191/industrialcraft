/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  net.minecraft.block.Block
 *  net.minecraft.init.Blocks
 *  net.minecraft.tileentity.TileEntity
 *  net.minecraft.util.ChunkCoordinates
 *  net.minecraft.world.World
 *  net.minecraft.world.WorldProvider
 *  net.minecraft.world.chunk.Chunk
 *  net.minecraftforge.common.DimensionManager
 *  net.minecraftforge.common.util.ForgeDirection
 */
package ic2.core.energy;

import ic2.api.Direction;
import ic2.api.energy.NodeStats;
import ic2.api.energy.tile.IEnergyAcceptor;
import ic2.api.energy.tile.IEnergyEmitter;
import ic2.api.energy.tile.IEnergySink;
import ic2.api.energy.tile.IEnergySource;
import ic2.api.energy.tile.IEnergyTile;
import ic2.api.energy.tile.IMetaDelegate;
import ic2.core.IC2;
import ic2.core.Platform;
import ic2.core.TickHandler;
import ic2.core.energy.Change;
import ic2.core.energy.EnergyNetGlobal;
import ic2.core.energy.Grid;
import ic2.core.energy.GridInfo;
import ic2.core.energy.Node;
import ic2.core.energy.NodeLink;
import ic2.core.energy.NodeType;
import ic2.core.energy.Tile;
import ic2.core.init.MainConfig;
import ic2.core.util.ConfigUtil;
import ic2.core.util.Log;
import ic2.core.util.LogCategory;
import ic2.core.util.PriorityExecutor;
import ic2.core.util.Util;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;
import java.util.Set;
import java.util.WeakHashMap;
import net.minecraft.block.Block;
import net.minecraft.init.Blocks;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.ChunkCoordinates;
import net.minecraft.world.World;
import net.minecraft.world.WorldProvider;
import net.minecraft.world.chunk.Chunk;
import net.minecraftforge.common.DimensionManager;
import net.minecraftforge.common.util.ForgeDirection;

public final class EnergyNetLocal {
    public static final boolean useLinearTransferModel = ConfigUtil.getBool(MainConfig.get(), "misc/useLinearTransferModel");
    public static final double nonConductorResistance = 0.2;
    public static final double sourceResistanceFactor = 0.0625;
    public static final double sinkResistanceFactor = 1.0;
    public static final double sourceCurrent = 17.0;
    public static final boolean enableCache = true;
    private static int nextGridUid = 0;
    private static int nextNodeUid = 0;
    protected final Set<Grid> grids = new HashSet<Grid>();
    protected List<Change> changes = new ArrayList<Change>();
    private final Map<ChunkCoordinates, Tile> registeredTiles = new HashMap<ChunkCoordinates, Tile>();
    private Map<TileEntity, Integer> pendingAdds = new WeakHashMap<TileEntity, Integer>();
    private final Set<Tile> removedTiles = new HashSet<Tile>();
    private boolean locked = false;
    private static final long logSuppressionTimeout = 300000000000L;
    private final Map<String, Long> recentLogs = new HashMap<String, Long>();

    protected void addTileEntity(TileEntity te) {
        this.addTileEntity(te, 0);
    }

    protected void addTileEntity(TileEntity te, int retry) {
        if (EnergyNetGlobal.debugTileManagement) {
            IC2.log.debug(LogCategory.EnergyNet, "EnergyNet.addTileEntity(%s, %d), world=%s, chunk=%s, this=%s", new Object[]{te, retry, te.getWorldObj(), te.getWorldObj().getChunkFromBlockCoords(te.xCoord, te.zCoord), this});
        }
        if (!(te instanceof IEnergyTile)) {
            this.logWarn("EnergyNet.addTileEntity: " + (Object)te + " doesn't implement IEnergyTile, aborting");
            return;
        }
        if (EnergyNetGlobal.checkApi && !Util.checkInterfaces(te.getClass())) {
            IC2.log.warn(LogCategory.EnergyNet, "EnergyNet.addTileEntity: %s doesn't implement its advertised interfaces completely.", Util.asString(te));
        }
        if (te.isInvalid()) {
            this.logWarn("EnergyNet.addTileEntity: " + (Object)te + " is invalid (TileEntity.isInvalid()), aborting");
            return;
        }
        if (te.getWorldObj() != DimensionManager.getWorld((int)te.getWorldObj().provider.dimensionId)) {
            this.logDebug("EnergyNet.addTileEntity: " + (Object)te + " is in an unloaded world, aborting");
            return;
        }
        if (this.locked) {
            this.logDebug("EnergyNet.addTileEntity: adding " + (Object)te + " while locked, postponing.");
            this.pendingAdds.put(te, retry);
            return;
        }
        Tile tile = new Tile(this, te);
        if (EnergyNetGlobal.debugTileManagement) {
            ArrayList<String> posStrings = new ArrayList<String>(tile.positions.size());
            for (TileEntity pos : tile.positions) {
                posStrings.add((Object)pos + " (" + pos.xCoord + "/" + pos.yCoord + "/" + pos.zCoord + ")");
            }
            IC2.log.debug(LogCategory.EnergyNet, "positions: %s", posStrings);
        }
        Iterator it = tile.positions.listIterator();
        while (it.hasNext()) {
            TileEntity pos = it.next();
            ChunkCoordinates coords = new ChunkCoordinates(pos.xCoord, pos.yCoord, pos.zCoord);
            Tile conflicting = this.registeredTiles.get((Object)coords);
            if (conflicting != null) {
                if (te == conflicting.entity) {
                    this.logDebug("EnergyNet.addTileEntity: " + (Object)pos + " (" + (Object)te + ") is already added using the same position, aborting");
                } else if (retry < 2) {
                    this.pendingAdds.put(te, retry + 1);
                } else if (conflicting.entity.isInvalid() || EnergyNetGlobal.replaceConflicting) {
                    this.logDebug("EnergyNet.addTileEntity: " + (Object)pos + " (" + (Object)te + ") is conflicting with " + (Object)conflicting.entity + " (invalid=" + conflicting.entity.isInvalid() + ") using the same position, which is abandoned (prev. te not removed), replacing");
                    this.removeTileEntity(conflicting.entity);
                    conflicting = null;
                } else {
                    this.logWarn("EnergyNet.addTileEntity: " + (Object)pos + " (" + (Object)te + ") is still conflicting with " + (Object)conflicting.entity + " using the same position (overlapping), aborting");
                }
                if (conflicting != null) {
                    it.previous();
                    while (it.hasPrevious()) {
                        pos = (TileEntity)it.previous();
                        coords = new ChunkCoordinates(pos.xCoord, pos.yCoord, pos.zCoord);
                        this.registeredTiles.remove((Object)coords);
                    }
                    return;
                }
            }
            if (!te.getWorldObj().blockExists(pos.xCoord, pos.yCoord, pos.zCoord)) {
                if (retry < 1) {
                    this.logWarn("EnergyNet.addTileEntity: " + (Object)pos + " (" + (Object)te + ") was added too early, postponing");
                    this.pendingAdds.put(te, retry + 1);
                } else {
                    this.logWarn("EnergyNet.addTileEntity: " + (Object)pos + " (" + (Object)te + ") unloaded, aborting");
                }
                it.previous();
                while (it.hasPrevious()) {
                    pos = (TileEntity)it.previous();
                    coords = new ChunkCoordinates(pos.xCoord, pos.yCoord, pos.zCoord);
                    this.registeredTiles.remove((Object)coords);
                }
                return;
            }
            this.registeredTiles.put(coords, tile);
            for (ForgeDirection dir : ForgeDirection.VALID_DIRECTIONS) {
                int x = pos.xCoord + dir.offsetX;
                int y = pos.yCoord + dir.offsetY;
                int z = pos.zCoord + dir.offsetZ;
                if (!te.getWorldObj().blockExists(x, y, z)) continue;
                te.getWorldObj().notifyBlockOfNeighborChange(x, y, z, Blocks.air);
            }
        }
        this.addTileToGrids(tile);
        if (EnergyNetGlobal.verifyGrid()) {
            for (Node node : tile.nodes) {
                assert (node.getGrid() != null);
            }
        }
    }

    protected void removeTileEntity(TileEntity te) {
        boolean wasPending;
        if (this.locked) {
            throw new IllegalStateException("removeTileEntity isn't allowed from this context");
        }
        if (EnergyNetGlobal.debugTileManagement) {
            IC2.log.debug(LogCategory.EnergyNet, "EnergyNet.removeTileEntity(%s), world=%s, chunk=%s, this=%s", new Object[]{te, te.getWorldObj(), te.getWorldObj().getChunkFromBlockCoords(te.xCoord, te.zCoord), this});
        }
        if (!(te instanceof IEnergyTile)) {
            this.logWarn("EnergyNet.removeTileEntity: " + (Object)te + " doesn't implement IEnergyTile, aborting");
            return;
        }
        List<TileEntity> positions = te instanceof IMetaDelegate ? ((IMetaDelegate)te).getSubTiles() : Arrays.asList(new TileEntity[]{te});
        boolean bl = wasPending = this.pendingAdds.remove((Object)te) != null;
        if (EnergyNetGlobal.debugTileManagement) {
            ArrayList<String> posStrings = new ArrayList<String>(positions.size());
            for (TileEntity pos : positions) {
                posStrings.add((Object)pos + " (" + pos.xCoord + "/" + pos.yCoord + "/" + pos.zCoord + ")");
            }
            IC2.log.debug(LogCategory.EnergyNet, "positions: %s", posStrings);
        }
        boolean removed = false;
        for (TileEntity pos : positions) {
            ChunkCoordinates coords = new ChunkCoordinates(pos.xCoord, pos.yCoord, pos.zCoord);
            Tile tile = this.registeredTiles.get((Object)coords);
            if (tile == null) {
                if (wasPending) continue;
                this.logDebug("EnergyNet.removeTileEntity: " + (Object)pos + " (" + (Object)te + ") wasn't found (added), skipping");
                continue;
            }
            if (tile.entity != te) {
                this.logWarn("EnergyNet.removeTileEntity: " + (Object)pos + " (" + (Object)te + ") doesn't match the registered te " + (Object)tile.entity + ", skipping");
                continue;
            }
            if (!removed) {
                assert (new HashSet<TileEntity>(positions).equals(new HashSet<TileEntity>(tile.positions)));
                this.removeTileFromGrids(tile);
                removed = true;
                this.removedTiles.add(tile);
            }
            this.registeredTiles.remove((Object)coords);
            if (!te.getWorldObj().blockExists(pos.xCoord, pos.yCoord, pos.zCoord)) continue;
            for (ForgeDirection dir : ForgeDirection.VALID_DIRECTIONS) {
                int x = pos.xCoord + dir.offsetX;
                int y = pos.yCoord + dir.offsetY;
                int z = pos.zCoord + dir.offsetZ;
                if (!te.getWorldObj().blockExists(x, y, z)) continue;
                te.getWorldObj().notifyBlockOfNeighborChange(x, y, z, Blocks.air);
            }
        }
    }

    protected double getTotalEnergyEmitted(TileEntity tileEntity) {
        ChunkCoordinates coords = new ChunkCoordinates(tileEntity.xCoord, tileEntity.yCoord, tileEntity.zCoord);
        Tile tile = this.registeredTiles.get((Object)coords);
        if (tile == null) {
            this.logWarn("EnergyNet.getTotalEnergyEmitted: " + (Object)tileEntity + " is not added to the enet, aborting");
            return 0.0;
        }
        double ret = 0.0;
        Iterable<NodeStats> stats = tile.getStats();
        for (NodeStats stat : stats) {
            ret += stat.getEnergyOut();
        }
        return ret;
    }

    protected double getTotalEnergySunken(TileEntity tileEntity) {
        ChunkCoordinates coords = new ChunkCoordinates(tileEntity.xCoord, tileEntity.yCoord, tileEntity.zCoord);
        Tile tile = this.registeredTiles.get((Object)coords);
        if (tile == null) {
            this.logWarn("EnergyNet.getTotalEnergySunken: " + (Object)tileEntity + " is not added to the enet, aborting");
            return 0.0;
        }
        double ret = 0.0;
        Iterable<NodeStats> stats = tile.getStats();
        for (NodeStats stat : stats) {
            ret += stat.getEnergyIn();
        }
        return ret;
    }

    protected NodeStats getNodeStats(TileEntity te) {
        ChunkCoordinates coords = new ChunkCoordinates(te.xCoord, te.yCoord, te.zCoord);
        Tile tile = this.registeredTiles.get((Object)coords);
        if (tile == null) {
            this.logWarn("EnergyNet.getTotalEnergySunken: " + (Object)te + " is not added to the enet, aborting");
            return new NodeStats(0.0, 0.0, 0.0);
        }
        double in = 0.0;
        double out = 0.0;
        double voltage = 0.0;
        Iterable<NodeStats> stats = tile.getStats();
        for (NodeStats stat : stats) {
            in += stat.getEnergyIn();
            out += stat.getEnergyOut();
            voltage = Math.max(voltage, stat.getVoltage());
        }
        return new NodeStats(in, out, voltage);
    }

    protected TileEntity getTileEntity(int x, int y, int z) {
        Tile ret = this.registeredTiles.get((Object)new ChunkCoordinates(x, y, z));
        if (ret == null) {
            return null;
        }
        return ret.entity;
    }

    protected TileEntity getNeighbor(TileEntity te, Direction dir) {
        switch (dir) {
            case XN: {
                return this.getTileEntity(te.xCoord - 1, te.yCoord, te.zCoord);
            }
            case XP: {
                return this.getTileEntity(te.xCoord + 1, te.yCoord, te.zCoord);
            }
            case YN: {
                return this.getTileEntity(te.xCoord, te.yCoord - 1, te.zCoord);
            }
            case YP: {
                return this.getTileEntity(te.xCoord, te.yCoord + 1, te.zCoord);
            }
            case ZN: {
                return this.getTileEntity(te.xCoord, te.yCoord, te.zCoord - 1);
            }
            case ZP: {
                return this.getTileEntity(te.xCoord, te.yCoord, te.zCoord + 1);
            }
        }
        return null;
    }

    public boolean dumpDebugInfo(PrintStream console, PrintStream chat, int x, int y, int z) {
        Tile tile = this.registeredTiles.get((Object)new ChunkCoordinates(x, y, z));
        if (tile == null) {
            return false;
        }
        HashSet<Grid> processedGrids = new HashSet<Grid>();
        for (Node node : tile.nodes) {
            Grid grid = node.getGrid();
            if (!processedGrids.add(grid)) continue;
            grid.dumpNodeInfo(chat, true, node);
            grid.dumpStats(chat, true);
            grid.dumpMatrix(console, true, true, true);
            console.println("dumping graph for " + grid);
            grid.dumpGraph(true);
        }
        return true;
    }

    public List<GridInfo> getGridInfos() {
        ArrayList<GridInfo> ret = new ArrayList<GridInfo>();
        for (Grid grid : this.grids) {
            ret.add(grid.getInfo());
        }
        return ret;
    }

    protected void onTickEnd() {
        if (!IC2.platform.isSimulating()) {
            return;
        }
        this.locked = true;
        for (Grid grid : this.grids) {
            grid.finishCalculation();
            grid.updateStats();
        }
        this.locked = false;
        this.processChanges();
        Map<TileEntity, Integer> currentPendingAdds = this.pendingAdds;
        this.pendingAdds = new WeakHashMap<TileEntity, Integer>();
        for (Map.Entry<TileEntity, Integer> entry : currentPendingAdds.entrySet()) {
            this.addTileEntity(entry.getKey(), entry.getValue());
        }
        this.locked = true;
        for (Grid grid2 : this.grids) {
            grid2.prepareCalculation();
        }
        ArrayList<Runnable> tasks = new ArrayList<Runnable>();
        for (Grid grid3 : this.grids) {
            Runnable task = grid3.startCalculation();
            if (task == null) continue;
            tasks.add(task);
        }
        IC2.getInstance().threadPool.executeAll(tasks);
        this.locked = false;
    }

    protected void addChange(Node node, ForgeDirection dir, double amount, double voltage) {
        this.changes.add(new Change(node, dir, amount, voltage));
    }

    protected static int getNextGridUid() {
        return nextGridUid++;
    }

    protected static int getNextNodeUid() {
        return nextNodeUid++;
    }

    private void addTileToGrids(Tile tile) {
        ArrayList<Node> extraNodes = new ArrayList<Node>();
        for (Node node2 : tile.nodes) {
            Grid grid;
            if (EnergyNetGlobal.debugGrid) {
                IC2.log.debug(LogCategory.EnergyNet, "Adding node %s.", node2);
            }
            ArrayList<Node> neighbors = new ArrayList<Node>();
            for (TileEntity pos2 : tile.positions) {
                for (Direction dir : Direction.directions) {
                    ForgeDirection fdir = dir.toForgeDirection();
                    ChunkCoordinates coords = new ChunkCoordinates(pos2.xCoord + fdir.offsetX, pos2.yCoord + fdir.offsetY, pos2.zCoord + fdir.offsetZ);
                    Tile neighborTile = this.registeredTiles.get((Object)coords);
                    if (neighborTile == null || neighborTile == node2.tile) continue;
                    for (Node neighbor : neighborTile.nodes) {
                        if (neighbor.isExtraNode()) continue;
                        boolean canEmit = false;
                        if ((node2.nodeType == NodeType.Source || node2.nodeType == NodeType.Conductor) && neighbor.nodeType != NodeType.Source) {
                            IEnergyEmitter emitter = (IEnergyEmitter)(pos2 instanceof IEnergyEmitter ? pos2 : node2.tile.entity);
                            TileEntity neighborSubTe = neighborTile.getSubEntityAt(coords);
                            IEnergyAcceptor acceptor = (IEnergyAcceptor)(neighborSubTe instanceof IEnergyAcceptor ? neighborSubTe : neighbor.tile.entity);
                            canEmit = emitter.emitsEnergyTo(neighbor.tile.entity, dir.toForgeDirection()) && acceptor.acceptsEnergyFrom(node2.tile.entity, dir.getInverse().toForgeDirection());
                        }
                        boolean canAccept = false;
                        if (!(canEmit || node2.nodeType != NodeType.Sink && node2.nodeType != NodeType.Conductor || neighbor.nodeType == NodeType.Sink)) {
                            IEnergyAcceptor acceptor = (IEnergyAcceptor)(pos2 instanceof IEnergyAcceptor ? pos2 : node2.tile.entity);
                            TileEntity neighborSubTe = neighborTile.getSubEntityAt(coords);
                            IEnergyEmitter emitter = (IEnergyEmitter)(neighborSubTe instanceof IEnergyEmitter ? neighborSubTe : neighbor.tile.entity);
                            boolean bl = canAccept = acceptor.acceptsEnergyFrom(neighbor.tile.entity, dir.toForgeDirection()) && emitter.emitsEnergyTo(node2.tile.entity, dir.getInverse().toForgeDirection());
                        }
                        if (!canEmit && !canAccept) continue;
                        neighbors.add(neighbor);
                    }
                }
            }
            if (neighbors.isEmpty()) {
                if (EnergyNetGlobal.debugGrid) {
                    IC2.log.debug(LogCategory.EnergyNet, "Creating new grid for %s.", node2);
                }
                grid = new Grid(this);
                grid.add(node2, neighbors);
                continue;
            }
            switch (node2.nodeType) {
                Node neighbor2;
                case Conductor: {
                    grid = null;
                    for (Node neighbor : neighbors) {
                        if (neighbor.nodeType != NodeType.Conductor && !neighbor.links.isEmpty()) continue;
                        if (EnergyNetGlobal.debugGrid) {
                            IC2.log.debug(LogCategory.EnergyNet, "Using %s for %s with neighbors %s.", neighbor.getGrid(), node2, neighbors);
                        }
                        grid = neighbor.getGrid();
                        break;
                    }
                    if (grid == null) {
                        if (EnergyNetGlobal.debugGrid) {
                            IC2.log.debug(LogCategory.EnergyNet, "Creating new grid for %s with neighbors %s.", node2, neighbors);
                        }
                        grid = new Grid(this);
                    }
                    HashMap<Node, Node> neighborReplacements = new HashMap<Node, Node>();
                    ListIterator<Node> it = neighbors.listIterator();
                    while (it.hasNext()) {
                        Node neighbor3 = it.next();
                        if (neighbor3.getGrid() == grid) continue;
                        if (neighbor3.nodeType != NodeType.Conductor && !neighbor3.links.isEmpty()) {
                            boolean found = false;
                            for (int i = 0; i < it.previousIndex(); ++i) {
                                neighbor2 = neighbors.get(i);
                                if (neighbor2.tile != neighbor3.tile || neighbor2.nodeType != neighbor3.nodeType || neighbor2.getGrid() != grid) continue;
                                if (EnergyNetGlobal.debugGrid) {
                                    IC2.log.debug(LogCategory.EnergyNet, "Using neighbor node %s instead of %s.", neighbor2, neighbors);
                                }
                                found = true;
                                it.set(neighbor2);
                                break;
                            }
                            if (found) continue;
                            if (EnergyNetGlobal.debugGrid) {
                                IC2.log.debug(LogCategory.EnergyNet, "Creating new extra node for neighbor %s.", neighbor3);
                            }
                            neighbor3 = new Node(this, neighbor3.tile, neighbor3.nodeType);
                            neighbor3.tile.addExtraNode(neighbor3);
                            grid.add(neighbor3, Collections.<Node>emptyList());
                            it.set(neighbor3);
                            assert (neighbor3.getGrid() != null);
                            continue;
                        }
                        grid.merge(neighbor3.getGrid(), neighborReplacements);
                    }
                    it = neighbors.listIterator();
                    while (it.hasNext()) {
                        Node neighbor4 = it.next();
                        Node replacement = (Node)neighborReplacements.get(neighbor4);
                        if (replacement != null) {
                            neighbor4 = replacement;
                            it.set(replacement);
                        }
                        assert (neighbor4.getGrid() == grid);
                    }
                    grid.add(node2, neighbors);
                    assert (node2.getGrid() != null);
                    break;
                }
                case Sink: 
                case Source: {
                    ArrayList neighborGroups = new ArrayList();
                    for (Node neighbor : neighbors) {
                        boolean found = false;
                        if (node2.nodeType == NodeType.Conductor) {
                            for (List nodeList : neighborGroups) {
                                neighbor2 = (Node)nodeList.get(0);
                                if (neighbor2.nodeType != NodeType.Conductor || neighbor2.getGrid() != neighbor.getGrid()) continue;
                                nodeList.add(neighbor);
                                found = true;
                                break;
                            }
                        }
                        if (found) continue;
                        ArrayList<Node> nodeList = new ArrayList<Node>();
                        nodeList.add(neighbor);
                        neighborGroups.add(nodeList);
                    }
                    if (EnergyNetGlobal.debugGrid) {
                        IC2.log.debug(LogCategory.EnergyNet, "Neighbor groups detected for %s: %s.", node2, neighborGroups);
                    }
                    assert (!neighborGroups.isEmpty());
                    boolean i = false;
                    while (++i < neighborGroups.size()) {
                        Node currentNode;
                        List nodeList = (List)neighborGroups.get((int)i);
                        Node neighbor3 = (Node)nodeList.get(0);
                        if (neighbor3.nodeType != NodeType.Conductor && !neighbor3.links.isEmpty()) {
                            assert (nodeList.size() == 1);
                            if (EnergyNetGlobal.debugGrid) {
                                IC2.log.debug(LogCategory.EnergyNet, "Creating new extra node for neighbor %s.", neighbor3);
                            }
                            neighbor3 = new Node(this, neighbor3.tile, neighbor3.nodeType);
                            neighbor3.tile.addExtraNode(neighbor3);
                            new Grid(this).add(neighbor3, Collections.<Node>emptyList());
                            nodeList.set(0, neighbor3);
                            assert (neighbor3.getGrid() != null);
                        }
                        if (i == false) {
                            currentNode = node2;
                        } else {
                            if (EnergyNetGlobal.debugGrid) {
                                IC2.log.debug(LogCategory.EnergyNet, "Creating new extra node for %s.", node2);
                            }
                            currentNode = new Node(this, tile, node2.nodeType);
                            currentNode.setExtraNode(true);
                            extraNodes.add(currentNode);
                        }
                        neighbor3.getGrid().add(currentNode, nodeList);
                        if ($assertionsDisabled || currentNode.getGrid() != null) continue;
                        throw new AssertionError();
                    }
                    break block0;
                }
            }
        }
        for (Node node : extraNodes) {
            tile.addExtraNode(node);
        }
    }

    private void removeTileFromGrids(Tile tile) {
        for (Node node : tile.nodes) {
            node.getGrid().remove(node);
        }
    }

    private void processChanges() {
        for (Tile tile : this.removedTiles) {
            Iterator<Change> it = this.changes.iterator();
            while (it.hasNext()) {
                Change change = it.next();
                if (change.node.tile != tile) continue;
                Tile replacement = this.registeredTiles.get((Object)new ChunkCoordinates(change.node.tile.entity.xCoord, change.node.tile.entity.yCoord, change.node.tile.entity.zCoord));
                boolean validReplacement = false;
                if (replacement != null) {
                    for (Node node2 : replacement.nodes) {
                        if (node2.nodeType != change.node.nodeType || node2.getGrid() != change.node.getGrid()) continue;
                        if (EnergyNetGlobal.debugGrid) {
                            IC2.log.debug(LogCategory.EnergyNet, "Redirecting change %s to replacement node %s.", change, node2);
                        }
                        change.node = node2;
                        validReplacement = true;
                        break;
                    }
                }
                if (validReplacement) continue;
                it.remove();
                Iterator<Change> sameGridSourceChanges = new ArrayList();
                for (Change change22 : this.changes) {
                    if (change22.node.nodeType != NodeType.Source || change.node.getGrid() != change22.node.getGrid()) continue;
                    sameGridSourceChanges.add(change22);
                }
                if (EnergyNetGlobal.debugGrid) {
                    IC2.log.debug(LogCategory.EnergyNet, "Redistributing change %s to remaining source nodes %s.", change, sameGridSourceChanges);
                }
                Iterator node2 = sameGridSourceChanges.iterator();
                while (node2.hasNext()) {
                    Change change2 = (Change)node2.next();
                    change2.setAmount(change2.getAmount() - Math.abs(change.getAmount()) / (double)sameGridSourceChanges.size());
                }
            }
        }
        this.removedTiles.clear();
        for (Change change2 : this.changes) {
            if (change2.node.nodeType != NodeType.Sink) continue;
            assert (change2.getAmount() > 0.0);
            IEnergySink sink = (IEnergySink)change2.node.tile.entity;
            double returned = sink.injectEnergy(change2.dir, change2.getAmount(), change2.getVoltage());
            if (EnergyNetGlobal.debugGrid) {
                IC2.log.debug(LogCategory.EnergyNet, "Applied change %s, %f EU returned.", change2, returned);
            }
            if (returned <= 0.0) continue;
            ArrayList<Change> sameGridSourceChanges = new ArrayList<Change>();
            for (Change change23 : this.changes) {
                if (change23.node.nodeType != NodeType.Source || change2.node.getGrid() != change23.node.getGrid()) continue;
                sameGridSourceChanges.add(change23);
            }
            if (EnergyNetGlobal.debugGrid) {
                IC2.log.debug(LogCategory.EnergyNet, "Redistributing returned amount to source nodes %s.", sameGridSourceChanges);
            }
            for (Change change22 : sameGridSourceChanges) {
                change22.setAmount(change22.getAmount() - returned / (double)sameGridSourceChanges.size());
            }
        }
        for (Change change : this.changes) {
            if (change.node.nodeType != NodeType.Source) continue;
            assert (change.getAmount() <= 0.0);
            if (change.getAmount() >= 0.0) continue;
            IEnergySource source = (IEnergySource)change.node.tile.entity;
            source.drawEnergy(change.getAmount());
            if (!EnergyNetGlobal.debugGrid) continue;
            IC2.log.debug(LogCategory.EnergyNet, "Applied change %s.", change);
        }
        this.changes.clear();
    }

    private void logDebug(String msg) {
        if (!this.shouldLog(msg)) {
            return;
        }
        IC2.log.debug(LogCategory.EnergyNet, msg);
        if (EnergyNetGlobal.debugTileManagement) {
            IC2.log.debug(LogCategory.EnergyNet, new Throwable(), "stack trace");
            if (TickHandler.getLastDebugTrace() != null) {
                IC2.log.debug(LogCategory.EnergyNet, TickHandler.getLastDebugTrace(), "parent stack trace");
            }
        }
    }

    private void logWarn(String msg) {
        if (!this.shouldLog(msg)) {
            return;
        }
        IC2.log.warn(LogCategory.EnergyNet, msg);
        if (EnergyNetGlobal.debugTileManagement) {
            IC2.log.debug(LogCategory.EnergyNet, new Throwable(), "stack trace");
            if (TickHandler.getLastDebugTrace() != null) {
                IC2.log.debug(LogCategory.EnergyNet, TickHandler.getLastDebugTrace(), "parent stack trace");
            }
        }
    }

    private boolean shouldLog(String msg) {
        if (EnergyNetGlobal.logAll) {
            return true;
        }
        this.cleanRecentLogs();
        msg = msg.replaceAll("@[0-9a-f]+", "@x");
        long time = System.nanoTime();
        Long lastLog = this.recentLogs.put(msg, time);
        return lastLog == null || lastLog < time - 300000000000L;
    }

    private void cleanRecentLogs() {
        if (this.recentLogs.size() < 100) {
            return;
        }
        long minTime = System.nanoTime() - 300000000000L;
        Iterator<Long> it = this.recentLogs.values().iterator();
        while (it.hasNext()) {
            long recTime = it.next();
            if (recTime >= minTime) continue;
            it.remove();
        }
    }

}

