/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  net.minecraft.world.World
 */
package ic2.core;

import net.minecraft.world.World;

public interface ITickCallback {
    public void tickCallback(World var1);
}

