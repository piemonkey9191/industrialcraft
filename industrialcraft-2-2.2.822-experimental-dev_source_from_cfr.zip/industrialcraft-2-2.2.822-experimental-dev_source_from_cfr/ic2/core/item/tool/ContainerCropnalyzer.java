/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  net.minecraft.entity.player.EntityPlayer
 *  net.minecraft.inventory.IInventory
 *  net.minecraft.inventory.Slot
 *  net.minecraft.item.Item
 *  net.minecraft.item.ItemStack
 */
package ic2.core.item.tool;

import ic2.core.Ic2Items;
import ic2.core.item.ContainerHandHeldInventory;
import ic2.core.item.tool.HandHeldCropnalyzer;
import ic2.core.slot.SlotCustom;
import ic2.core.slot.SlotDischarge;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.inventory.IInventory;
import net.minecraft.inventory.Slot;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;

public class ContainerCropnalyzer
extends ContainerHandHeldInventory<HandHeldCropnalyzer> {
    public ContainerCropnalyzer(EntityPlayer player, HandHeldCropnalyzer cropnalyzer1, int height) {
        super(cropnalyzer1);
        this.addSlotToContainer((Slot)new SlotCustom(cropnalyzer1, Ic2Items.cropSeed.getItem(), 0, 8, 7));
        this.addSlotToContainer((Slot)new SlotCustom(cropnalyzer1, null, 1, 41, 7));
        this.addSlotToContainer((Slot)new SlotDischarge(cropnalyzer1, 2, 152, 7));
        this.addPlayerInventorySlots(player, height);
    }
}

