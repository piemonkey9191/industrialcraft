/*
 * Decompiled with CFR 0_115.
 */
package ic2.core.block.wiring;

import ic2.core.block.wiring.TileEntityTransformer;

public class TileEntityTransformerMV
extends TileEntityTransformer {
    public TileEntityTransformerMV() {
        super(2);
    }

    @Override
    public String getInventoryName() {
        return "TransformerMV";
    }
}

