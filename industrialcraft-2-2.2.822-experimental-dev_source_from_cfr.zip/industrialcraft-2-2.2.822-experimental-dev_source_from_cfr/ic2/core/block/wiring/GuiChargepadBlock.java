/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  cpw.mods.fml.relauncher.Side
 *  cpw.mods.fml.relauncher.SideOnly
 *  net.minecraft.client.Minecraft
 *  net.minecraft.client.gui.FontRenderer
 *  net.minecraft.client.gui.GuiButton
 *  net.minecraft.client.gui.inventory.GuiContainer
 *  net.minecraft.client.renderer.texture.TextureManager
 *  net.minecraft.init.Items
 *  net.minecraft.inventory.Container
 *  net.minecraft.inventory.IInventory
 *  net.minecraft.item.Item
 *  net.minecraft.item.ItemStack
 *  net.minecraft.tileentity.TileEntity
 *  net.minecraft.util.ResourceLocation
 *  net.minecraft.util.StatCollector
 *  org.lwjgl.opengl.GL11
 */
package ic2.core.block.wiring;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import ic2.core.GuiIconButton;
import ic2.core.IC2;
import ic2.core.block.wiring.ContainerChargepadBlock;
import ic2.core.block.wiring.TileEntityChargepadBlock;
import ic2.core.network.NetworkManager;
import ic2.core.util.GuiTooltipHelper;
import ic2.core.util.SideGateway;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.inventory.GuiContainer;
import net.minecraft.client.renderer.texture.TextureManager;
import net.minecraft.init.Items;
import net.minecraft.inventory.Container;
import net.minecraft.inventory.IInventory;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.StatCollector;
import org.lwjgl.opengl.GL11;

@SideOnly(value=Side.CLIENT)
public class GuiChargepadBlock
extends GuiContainer {
    private final ContainerChargepadBlock container;
    private final String level;
    private final String name;
    private static final ResourceLocation background = new ResourceLocation(IC2.textureDomain, "textures/gui/GUIChargepadBlock.png");

    public GuiChargepadBlock(ContainerChargepadBlock container1) {
        super((Container)container1);
        this.container = container1;
        this.level = StatCollector.translateToLocal((String)"ic2.EUStorage.gui.info.level");
        switch (((TileEntityChargepadBlock)container1.base).tier) {
            case 1: {
                this.name = StatCollector.translateToLocal((String)"ic2.blockChargepadBatBox");
                break;
            }
            case 2: {
                this.name = StatCollector.translateToLocal((String)"ic2.blockChargepadCESU");
                break;
            }
            case 3: {
                this.name = StatCollector.translateToLocal((String)"ic2.blockChargepadMFE");
                break;
            }
            case 4: {
                this.name = StatCollector.translateToLocal((String)"ic2.blockChargepadMFSU");
                break;
            }
            default: {
                this.name = null;
            }
        }
    }

    protected void drawGuiContainerForegroundLayer(int par1, int par2) {
        this.fontRendererObj.drawString(this.name, (this.xSize - this.fontRendererObj.getStringWidth(this.name)) / 2, 6, 4210752);
        this.fontRendererObj.drawString(this.level, 79, 25, 4210752);
        int e = (int)Math.min(((TileEntityChargepadBlock)this.container.base).energy, (double)((TileEntityChargepadBlock)this.container.base).maxStorage);
        this.fontRendererObj.drawString(" " + e, 110, 35, 4210752);
        this.fontRendererObj.drawString("/" + ((TileEntityChargepadBlock)this.container.base).maxStorage, 110, 45, 4210752);
        GuiTooltipHelper.drawAreaTooltip(par1 - this.guiLeft, par2 - this.guiTop, ((TileEntityChargepadBlock)this.container.base).getredstoneMode(), 153, 3, 172, 22);
    }

    protected void drawGuiContainerBackgroundLayer(float f, int x, int y) {
        GL11.glColor4f((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
        this.mc.getTextureManager().bindTexture(background);
        int j = (this.width - this.xSize) / 2;
        int k = (this.height - this.ySize) / 2;
        this.drawTexturedModalRect(j, k, 0, 0, this.xSize, this.ySize);
        if (((TileEntityChargepadBlock)this.container.base).energy > 0.0) {
            int i1 = (int)(24.0f * ((TileEntityChargepadBlock)this.container.base).getChargeLevel());
            this.drawTexturedModalRect(j + 79, k + 34, 176, 14, i1 + 1, 16);
        }
    }

    public void initGui() {
        super.initGui();
        this.buttonList.add(new GuiIconButton(0, (this.width - this.xSize) / 2 + 152, (this.height - this.ySize) / 2 + 4, 20, 20, new ItemStack(Items.redstone), true));
    }

    protected void actionPerformed(GuiButton guibutton) {
        super.actionPerformed(guibutton);
        if (guibutton.id == 0) {
            IC2.network.get().initiateClientTileEntityEvent((TileEntity)this.container.base, 0);
        }
    }
}

