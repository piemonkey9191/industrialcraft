/*
 * Decompiled with CFR 0_115.
 */
package ic2.core.block.wiring;

import ic2.core.block.wiring.TileEntityTransformer;

public class TileEntityTransformerEV
extends TileEntityTransformer {
    public TileEntityTransformerEV() {
        super(4);
    }

    @Override
    public String getInventoryName() {
        return "TransformerUV";
    }
}

