/*
 * Decompiled with CFR 0_115.
 */
package ic2.core.block.wiring;

import ic2.core.block.wiring.TileEntityTransformer;

public class TileEntityTransformerLV
extends TileEntityTransformer {
    public TileEntityTransformerLV() {
        super(1);
    }

    @Override
    public String getInventoryName() {
        return "TransformerLV";
    }
}

