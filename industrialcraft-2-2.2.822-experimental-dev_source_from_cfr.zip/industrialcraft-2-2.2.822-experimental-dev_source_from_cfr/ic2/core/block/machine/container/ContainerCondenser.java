/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  net.minecraft.entity.player.EntityPlayer
 *  net.minecraft.inventory.Slot
 */
package ic2.core.block.machine.container;

import ic2.core.block.invslot.InvSlot;
import ic2.core.block.invslot.InvSlotConsumableId;
import ic2.core.block.invslot.InvSlotConsumableLiquidByTank;
import ic2.core.block.invslot.InvSlotOutput;
import ic2.core.block.invslot.InvSlotUpgrade;
import ic2.core.block.machine.container.ContainerElectricMachine;
import ic2.core.block.machine.tileentity.TileEntityCondenser;
import ic2.core.slot.SlotInvSlot;
import java.util.List;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.inventory.Slot;

public class ContainerCondenser
extends ContainerElectricMachine<TileEntityCondenser> {
    public ContainerCondenser(EntityPlayer entityPlayer, TileEntityCondenser tileEntite) {
        int i;
        super(entityPlayer, tileEntite, 184, 8, 44);
        this.addSlotToContainer((Slot)new SlotInvSlot(tileEntite.waterinputSlot, 0, 26, 73));
        this.addSlotToContainer((Slot)new SlotInvSlot(tileEntite.wateroutputSlot, 0, 134, 73));
        this.addSlotToContainer((Slot)new SlotInvSlot(tileEntite.upgradeSlot, 0, 152, 73));
        for (i = 0; i < 2; ++i) {
            this.addSlotToContainer((Slot)new SlotInvSlot(tileEntite.ventslots, i, 26 + i * 108, 26));
        }
        for (i = 2; i < 4; ++i) {
            this.addSlotToContainer((Slot)new SlotInvSlot(tileEntite.ventslots, i, 26 + (i - 2) * 108, 44));
        }
    }

    @Override
    public List<String> getNetworkedFields() {
        List<String> ret = super.getNetworkedFields();
        ret.add("inputTank");
        ret.add("outputTank");
        ret.add("progress");
        return ret;
    }
}

