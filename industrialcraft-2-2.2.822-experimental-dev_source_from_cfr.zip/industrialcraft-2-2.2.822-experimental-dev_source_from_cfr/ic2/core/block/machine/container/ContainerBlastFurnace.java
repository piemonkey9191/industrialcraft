/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  net.minecraft.entity.player.EntityPlayer
 *  net.minecraft.inventory.Slot
 */
package ic2.core.block.machine.container;

import ic2.core.ContainerFullInv;
import ic2.core.block.invslot.InvSlot;
import ic2.core.block.invslot.InvSlotConsumable;
import ic2.core.block.invslot.InvSlotOutput;
import ic2.core.block.invslot.InvSlotUpgrade;
import ic2.core.block.machine.tileentity.TileEntityBlastFurnace;
import ic2.core.slot.SlotInvSlot;
import java.util.List;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.inventory.Slot;

public class ContainerBlastFurnace
extends ContainerFullInv<TileEntityBlastFurnace> {
    public ContainerBlastFurnace(EntityPlayer entityPlayer, TileEntityBlastFurnace tileEntity) {
        super(entityPlayer, tileEntity, 166);
        this.addSlotToContainer((Slot)new SlotInvSlot(tileEntity.inputSlot, 0, 35, 33));
        this.addSlotToContainer((Slot)new SlotInvSlot(tileEntity.outputSlot, 0, 134, 56));
        this.addSlotToContainer((Slot)new SlotInvSlot(tileEntity.slagOutputSlot, 0, 152, 56));
        this.addSlotToContainer((Slot)new SlotInvSlot(tileEntity.airSlot, 0, 26, 56));
        this.addSlotToContainer((Slot)new SlotInvSlot(tileEntity.airOutputSlot, 0, 44, 56));
        for (int i = 0; i < 2; ++i) {
            this.addSlotToContainer((Slot)new SlotInvSlot(tileEntity.upgradeSlot, i, 152, 8 + i * 18));
        }
    }

    @Override
    public List<String> getNetworkedFields() {
        List<String> ret = super.getNetworkedFields();
        ret.add("heat");
        ret.add("progress");
        ret.add("outOfAir");
        return ret;
    }
}

