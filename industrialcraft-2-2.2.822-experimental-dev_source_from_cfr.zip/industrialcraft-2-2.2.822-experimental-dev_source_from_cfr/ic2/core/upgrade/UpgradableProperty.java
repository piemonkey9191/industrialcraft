/*
 * Decompiled with CFR 0_115.
 */
package ic2.core.upgrade;

public enum UpgradableProperty {
    Processing,
    Augmentable,
    RedstoneSensitive,
    Transformer,
    EnergyStorage,
    ItemConsuming,
    ItemProducing,
    FluidConsuming,
    FluidProducing;
    

    private UpgradableProperty() {
    }
}

