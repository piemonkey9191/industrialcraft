/*
 * Decompiled with CFR 0_115.
 */
package ic2.core.util;

public enum LogCategory {
    General,
    Audio,
    Block,
    EnergyNet,
    Item,
    Network,
    PlayerActivity,
    Recipe,
    Resource,
    SubModule,
    Uu;
    

    private LogCategory() {
    }
}

