/*
 * Decompiled with CFR 0_115.
 */
package ic2.core;

public interface IHitSoundOverride {
    public String getHitSoundForBlock(int var1, int var2, int var3);
}

